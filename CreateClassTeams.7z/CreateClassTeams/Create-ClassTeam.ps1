Function Get-ScriptDirectory
{
## 
##  DESCRIPTION 
##  	Getting the current script directory 
##  NOTES 
##  	Author: Sébastien Marchal, sebastien.marchal@uclouvain.be 
##  EXAMPLE 
##  	Get-ScriptDirectory
##
	$invocation = (Get-Variable MyInvocation -Scope 'Script').Value
	Split-Path $invocation.MyCommand.Path
}

Function Get-Classes
{
	$classes = Get-Content .\Cours.txt
	return $classes
}

function Connect-MsTeams($login)
{
	$result = $true
	
	#Obtention du mot de passe pour le compte 
	#Le fichier a été généré à l'aide des deux commandes suivantes
	#$credential = Get-Credential
	#$credential.Password | ConvertFrom-SecureString | Set-Content .\encrypted_password.txt
	$password = Get-Content $($(Get-ScriptDirectory) + "\" + "encrypted_password.txt") | ConvertTo-SecureString 

	#Création du credential pour Azure
	$cred = New-Object System.Management.Automation.PsCredential($login, $password)

	try
	{
		#Connexion à Ms Teams
		Connect-MicrosoftTeams -Credential $cred -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	
	return $result
}

function Create-Team($code)
{
	$finalName = 'Cours-' + $code
	
	try
	{
		$groupid = New-Team -Displayname $finalName -Template "EDU_Class" -Description "Cours $code" -Alias $finalName -ErrorAction Stop
	}
	catch
	{
		$groupid = -1
	}
	
	return $groupid
}

function Save-GroupId($code, $groupid)
{
	$result = $true
	
	try
	{
		Set-Content -Path ".\GroupId\$code.txt" -Value $groupid -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	
	return $result
}


#Paramètres globaux

#Login d'un administrateur de MS Teams ou d'un admin global du tenant
#Voir la fonction Connect-MsTeams pour le stockage du mot de passe
$login = 'big.brother@microsoft.com'

if($(Connect-MsTeams $login) -eq $true)
{
	Write-Host "Connect to Microsot Teams successfully" -Foregroundcolor green
	
	$classes = Get-Classes
	Foreach($classe in $classes)
	{
		Write-Host "Attempt to create $classe Class Team"
		$groupid = Create-Team $classe
		if($groupid -eq -1)
		{
			Write-Host "Unable to create $classe Class Team" -Foregroundcolor red
		}
		else
		{
			Write-Host "Create $classe Class Team successfully" -Foregroundcolor green
			if($(Save-GroupId $classe $groupid) -eq $true)
			{
				Write-Host "Save Groupid for $classe Class Team successfully - groupid:$groupid" -Foregroundcolor green
			}
			else
			{
				Write-Host "Unable to save groupid for $classe Class Team - groupid:$groupid" -Foregroundcolor red
			}
		}
	}
}
else
{
	Write-Host "Unable to connect to Microsot Teams" -Foregroundcolor red
}
