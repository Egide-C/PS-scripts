Function Get-ScriptDirectory
{
## 
##  DESCRIPTION 
##  	Getting the current script directory 
##  NOTES 
##  	Author: Sébastien Marchal, sebastien.marchal@uclouvain.be 
##  EXAMPLE 
##  	Get-ScriptDirectory
##
	$invocation = (Get-Variable MyInvocation -Scope 'Script').Value
	Split-Path $invocation.MyCommand.Path
}

Function Get-Classes
{
	try
	{
		$classes = Get-Content .\Cours.txt -ErrorAction Stop
	}
	catch
	{
		$classes = $null
	}
	
	return $classes
}

function Connect-MsTeams($login)
{
	$result = $true
	<#
	#Obtention du mot de passe pour le compte 
	#Le fichier a été généré à l'aide des deux commandes suivantes
	#$credential = Get-Credential
	#$credential.Password | ConvertFrom-SecureString | Set-Content .\encrypted_password.txt
	$password = Get-Content $($(Get-ScriptDirectory) + "\" + "encrypted_password.txt") | ConvertTo-SecureString 

	#Création du credential pour Azure
	$cred = New-Object System.Management.Automation.PsCredential($login, $password)

	try
	{
		#Connexion à Ms Teams
		Connect-MicrosoftTeams -Credential $cred -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	#>
	return $result
}

Function Get-Students($code)
{
	try
	{
		$students = Get-Content ".\Etudiant\$code.txt" -ErrorAction Stop
	}
	catch
	{
		$students = -1
	}
	
	return $students
}

Function Get-GroupId($code)
{
	try
	{
		$groupid = Get-Content ".\GroupId\$code.txt" -ErrorAction Stop
	}
	catch
	{
		$groupid = -1
	}
	
	return $groupid
}

function Add-StudentToTeam($groupid, $upn)
{
	$result = $true
	
	try
	{
		#On ajoute l'utilisateur
		Add-TeamUser -GroupId $groupid -User $upn -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	
	return $result
}

#Paramètres globaux

#Login d'un administrateur de MS Teams ou d'un admin global du tenant
#Voir la fonction Connect-MsTeams pour le stockage du mot de passe
$login = 'big.brother@microsoft.com'

if($(Connect-MsTeams $login) -eq $true)
{
	Write-Host "Connect to Microsot Teams successfully" -Foregroundcolor green
	
	$classes = Get-Classes
	Foreach($classe in $classes)
	{
		Write-Host "Attempt to get groupid for $classe Class Team"
		$groupid = Get-GroupId $classe
		if($groupid -eq -1)
		{
			Write-Host "Unable to get groupid for $classe Class Team" -Foregroundcolor red
		}
		else
		{
			Write-Host "Get groupid for $classe Class Team successfully - groupid: $groupid" -Foregroundcolor green
			$students = Get-Students $classe
			if($students -eq -1)
			{
				Write-Host "Unable to get students for $classe Class Team" -Foregroundcolor red
			}
			else
			{
				Write-Host "Get students for $classe Class Team successfully" -Foregroundcolor green
				foreach($student in $students)
				{
					if($(Add-StudentToTeam $groupid $student) -eq $true)
					{
						Write-Host "Add student $student to $classe Class Team successfully" -Foregroundcolor green
					}
					else
					{
						Write-Host "Unable to add student $student to $classe Class Team" -Foregroundcolor red
					}
				}
			}
		}
	}
}
else
{
	Write-Host "Unable to connect to Microsot Teams" -Foregroundcolor red
}
