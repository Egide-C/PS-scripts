Function Get-ScriptDirectory
{
## 
##  DESCRIPTION 
##  	Getting the current script directory 
##  NOTES 
##  	Author: Sébastien Marchal, sebastien.marchal@uclouvain.be 
##  EXAMPLE 
##  	Get-ScriptDirectory
##
	$invocation = (Get-Variable MyInvocation -Scope 'Script').Value
	Split-Path $invocation.MyCommand.Path
}

Function Get-Classes
{
	try
	{
		$classes = Get-Content .\Cours.txt -ErrorAction Stop
	}
	catch
	{
		$classes = $null
	}
	
	return $classes
}

function Connect-MsTeams($login)
{
	$result = $true
	
	#Obtention du mot de passe pour le compte 
	#Le fichier a été généré à l'aide des deux commandes suivantes
	#$credential = Get-Credential
	#$credential.Password | ConvertFrom-SecureString | Set-Content .\encrypted_password.txt
	$password = Get-Content $($(Get-ScriptDirectory) + "\" + "encrypted_password.txt") | ConvertTo-SecureString 

	#Création du credential pour Azure
	$cred = New-Object System.Management.Automation.PsCredential($login, $password)

	try
	{
		#Connexion à Ms Teams
		Connect-MicrosoftTeams -Credential $cred -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	
	return $result
}

Function Get-Teachers($code)
{
	try
	{
		$teachers = Get-Content ".\Enseignant\$code.txt" -ErrorAction Stop
	}
	catch
	{
		$teachers = -1
	}
	
	return $teachers
}

Function Get-GroupId($code)
{
	try
	{
		$groupid = Get-Content ".\GroupId\$code.txt" -ErrorAction Stop
	}
	catch
	{
		$groupid = -1
	}
	
	return $groupid
}

function Add-TeacherToTeam($groupid, $upn)
{
	$result = $true
	
	try
	{
		#On ajoute l'utilisateur avec le rôle Owner
		Add-TeamUser -GroupId $groupid -User $upn -Role Owner -ErrorAction Stop
	}
	catch
	{
		$result = $false
	}
	
	return $result
}

#Paramètres globaux

#Login d'un administrateur de MS Teams ou d'un admin global du tenant
#Voir la fonction Connect-MsTeams pour le stockage du mot de passe
$login = 'big.brother@microsoft.com'

if($(Connect-MsTeams $login) -eq $true)
{
	Write-Host "Connect to Microsot Teams successfully" -Foregroundcolor green
	
	$classes = Get-Classes
	Foreach($classe in $classes)
	{
		Write-Host "Attempt to get groupid for $classe Class Team"
		$groupid = Get-GroupId $classe
		if($groupid -eq -1)
		{
			Write-Host "Unable to get groupid for $classe Class Team" -Foregroundcolor red
		}
		else
		{
			Write-Host "Get groupid for $classe Class Team successfully - groupid: $groupid" -Foregroundcolor green
			$teachers = Get-Teachers $classe
			if($teachers -eq -1)
			{
				Write-Host "Unable to get teachers for $classe Class Team" -Foregroundcolor red
			}
			else
			{
				Write-Host "Get teachers for $classe Class Team successfully" -Foregroundcolor green
				foreach($teacher in $teachers)
				{
					if($(Add-TeacherToTeam $groupid $teacher) -eq $true)
					{
						Write-Host "Add teacher $teacher to $classe Class Team successfully" -Foregroundcolor green
					}
					else
					{
						Write-Host "Unable to add teacher $teacher to $classe Class Team" -Foregroundcolor red
					}
				}
			}
		}
	}
}
else
{
	Write-Host "Unable to connect to Microsot Teams" -Foregroundcolor red
}
